import "./style.css";

function CardBolo() {
    return (
        <div id="card">
            <div>
                <img
                    src={""}
                    alt={"Foto de um "}
                />
            </div>
            <div className="card_bolo_texto">
                <h2></h2>
                <div>
                    <span>Ingredientes:</span>
                    <p>Bolo:</p>
                    <p>Cobertura:</p>
                </div>
                <span>R$</span>
            </div>
        </div>
    );
};

export default CardBolo;


